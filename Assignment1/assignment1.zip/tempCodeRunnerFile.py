original= "E401_S366_I_Hate_School"
    # answer =""
    
    # idx1 = original.index("_")
    # idx2 = original.index("_", idx1+1)
    # remain = original[idx2+1:]
    # remain = remain.replace('_', ' ')
    
    # answer = answer + "Episode " + original[1:idx1] + " Season " + original[idx1+2:idx2] + " " + remain + " (The Simpsons)"
    
    # print(answer)